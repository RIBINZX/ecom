from django.shortcuts import render
from . models import Student
from django.shortcuts import redirect
from django.contrib import messages
# Create your views here.
def index(request):
    if request.method=="POST":
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        age = request.POST.get('age')
        
        # gender = request.POST.get('gender')
        
        

        form = Student(
            firstname = firstname,
            lastname = lastname,
            age = age,
        
           
        )
        form.save()
        messages.success(request,"succsessfully saved")
        return redirect('/')
    return render(request,'index.html')